"use client";

import { motion } from "motion/react";
import { MessageCircle } from "lucide-react";
import { site } from "@/lib/site";

export function WhatsAppButton() {
  return (
    <motion.a
      href={site.whatsappHref}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Escribinos por WhatsApp (se abre en una pestaña nueva)"
      initial={{ opacity: 0, scale: 0.6, y: 20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      transition={{ delay: 2.6, type: "spring", stiffness: 260, damping: 20 }}
      whileHover={{ scale: 1.06 }}
      whileTap={{ scale: 0.95 }}
      className="group fixed bottom-5 right-5 z-40 flex items-center gap-2 rounded-full bg-cera p-4 text-tinta shadow-[0_12px_30px_-8px_rgb(18_26_32/0.5)] md:bottom-8 md:right-8"
    >
      <MessageCircle className="size-6" aria-hidden="true" />
      <span className="max-w-0 overflow-hidden whitespace-nowrap text-sm font-semibold transition-[max-width] duration-500 ease-out group-hover:max-w-40 group-focus-visible:max-w-40">
        Escribinos
      </span>
    </motion.a>
  );
}
